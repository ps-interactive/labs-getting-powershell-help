#finding help

#get-command
help *process*
help *process
get-command -noun process
get-help stop-process
help stop-process
cls

#you can get help from an alias
help dir
help gsv

#the man alias only works on Windows
help man
man man
cls
