#about topics
# make sure about topics have been downloaded
help alias
help about_aliases
help about_*

help about_split -ShowWindow

cls

#there is tab completion for the about topic name
# about_s<tab>
